jQuery(function() {
	initSlickCarousel();
});

//slick init
function initSlickCarousel() {    
    const slickSlider = jQuery('.carousel-holder');
    const thumbList = $('<ul class="thumb-list"></ul>');   

    slickSlider.on("init", function(event, slick) {
        const sliderThumbs = slick.$slides.find('img').clone();
        const images = Array.from(sliderThumbs);

        images.forEach((img) => {
            const li = $('<li></li>');
            const link = $('<a></a>');
            link.append(img);
            li.append(link);
            thumbList.append(li);
        })   

        slickSlider.append(thumbList);

        thumbList.find('li').first().addClass('slick-active');

		thumbList.find('li').on('click', function(e) {
            slideIndex = $(this).index();
            slickSlider.slick('slickGoTo', slideIndex);

            thumbList.find('.slick-active').removeClass('slick-active');
            $(this).addClass('slick-active');
        });
        
    });
    
    slickSlider.slick({
        arrows: false
    })
    
    .on('beforeChange', function(event, slick) {
		thumbList.off('click');
	})
	
	.on('afterChange', function(event, slick, currentSlide) {
        thumbList.find('li').on('click', function(e) {
            slideIndex = $(this).index();
            slickSlider.slick('slickGoTo', slideIndex);

            thumbList.find('.slick-active').removeClass('slick-active');
            $(this).addClass('slick-active');
        });
	})
}